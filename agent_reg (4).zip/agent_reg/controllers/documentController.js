const DocumentSubmission = require("../models/documentSubmission");
const Document = require("../models/document");
const logger = require("../utils/logger");
const sendEmail = require("../utils/emailService");
const Agent = require("../models/agent");
const User = require("../models/user");
const Notification = require("../models/notification");

//create submission

exports.createSubmission = async (req, res, next) => {
  try {

    logger.info("POST /submission API called");

    const user = await User.findById(req.user.id);

    if (!user) {
      logger.warn(`User not found for id: ${req.user.id}`);
      return res.status(404).json({
        message: "User not found"
      });
    }

    if (user.role !== "AGENT") {
      logger.warn(`Unauthorized submission attempt by user ${user._id}`);
      return res.status(403).json({
        message: "Only agents can create submissions"
      });
    }

    logger.info(`Agent submission request by user: ${user._id}`);

    const agent = await Agent.findOne({ userId: user._id });

    if (!agent) {
      logger.warn(`Agent not found for userId: ${user._id}`);
      return res.status(404).json({
        message: "Agent not found"
      });
    }

    logger.info(`Agent found: ${agent._id}`);

    const existingSubmission = await DocumentSubmission.findOne({
      agentId: agent._id
    });

    if (existingSubmission) {
      logger.warn(`Submission already exists for agent: ${agent._id}`);
      return res.status(400).json({
        message: "Submission already exists"
      });
    }

    logger.info(`Creating new submission for agent: ${agent._id}`);

    const submission = await DocumentSubmission.create({
      agentId: agent._id,
      status: "DRAFT"
    });

    logger.info(`Submission created successfully: ${submission._id}`);

    res.status(201).json({
      submissionId: submission._id,
      status: submission.status,
      message: "Document submission created."
    });

  } catch (error) {

    logger.error("Error in createSubmission API", error);

    next(error);
  }
};

//upload document

exports.uploadDocument = async (req, res, next) => {
  try {

    logger.info("POST /uploadDocument API called");

    const user = await User.findById(req.user.id);

    if (!user) {
      logger.warn(`User not found: ${req.user.id}`);
      return res.status(404).json({
        message: "User not found"
      });
    }

    if (user.role !== "AGENT") {
      logger.warn(`Unauthorized upload attempt by user ${user._id}`);
      return res.status(403).json({
        message: "Only agents can upload documents"
      });
    }

    const { id } = req.params;

    logger.info(`Upload request for submissionId: ${id}`);

    const agent = await Agent.findOne({ userId: user._id });

    if (!agent) {
      logger.warn(`Agent not found for userId: ${user._id}`);
      return res.status(404).json({
        message: "Agent not found"
      });
    }

    const submission = await DocumentSubmission.findById(id);

    if (!submission) {
      logger.warn(`Submission not found: ${id}`);
      return res.status(404).json({
        message: "Submission not found"
      });
    }

    if (submission.agentId.toString() !== agent._id.toString()) {
      logger.warn(`Agent ${agent._id} attempted upload to unauthorized submission ${id}`);
      return res.status(403).json({
        message: "You cannot upload documents to this submission"
      });
    }

    if (submission.status === "SUBMITTED") {
      logger.warn(`Upload blocked. Submission already submitted: ${id}`);
      return res.status(400).json({
        message: "Documents already submitted. Upload not allowed."
      });
    }

    //  MULTIPLE FILE VALIDATION
    if (!req.files || req.files.length === 0) {
      logger.warn(`No files uploaded by agent ${agent._id}`);
      return res.status(400).json({
        message: "No files uploaded"
      });
    }

    //  CHECK TOTAL COUNT BEFORE INSERT
    const existingCount = await Document.countDocuments({
      submissionId: submission._id
    });

    if (existingCount >= 3) {
      logger.warn(`Document upload limit already reached for submission ${submission._id}`);
      return res.status(400).json({
        message: "Maximum 3 documents already uploaded"
      });
    }

    const uploadedDocuments = [];

    for (const file of req.files) {

      //  Duplicate check
      const existingDocument = await Document.findOne({
        submissionId: submission._id,
        originalFileName: file.originalname
      });

      if (existingDocument) {
        logger.warn(`Duplicate skipped: ${file.originalname}`);
        continue;
      }

  
      const currentCount = await Document.countDocuments({
        submissionId: submission._id
      });

      if (currentCount >= 3) {
        logger.warn(`Upload limit reached while processing files`);
        break;
      }

      logger.info(`Uploading document ${file.originalname}`);

      const document = await Document.create({
        submissionId: submission._id,
        fileName: file.filename,
        fileUrl: file.path,
        originalFileName: file.originalname,
        contentType: file.mimetype,
        fileSizeBytes: file.size
      });

      uploadedDocuments.push(document);
    }

    if (uploadedDocuments.length === 0) {
      return res.status(400).json({
        message: "No new documents uploaded (duplicates or limit reached)"
      });
    }

    logger.info(`Total documents uploaded: ${uploadedDocuments.length}`);

    res.status(201).json({
      message: "Documents uploaded successfully",
      documents: uploadedDocuments.map(doc => ({
        documentId: doc._id,
        fileName: doc.originalFileName
      }))
    });

  } catch (error) {
    logger.error("Error in uploadDocument API", error);
    next(error);
  }
};

//submit documents
exports.submitDocuments = async (req, res, next) => {

  try {

    logger.info("POST /submitDocuments API called");

    const user = await User.findById(req.user.id);

    if (!user) {
      logger.warn(`User not found: ${req.user.id}`);
      return res.status(404).json({
        message: "User not found"
      });
    }

    if (user.role !== "AGENT") {
      logger.warn(`Unauthorized submission attempt by user ${user._id}`);
      return res.status(403).json({
        message: "Only agents can submit documents"
      });
    }

    const { id } = req.params;

    logger.info(`Submission request received for submissionId: ${id}`);

    const agent = await Agent.findOne({ userId: user._id });

    if (!agent) {
      logger.warn(`Agent not found for userId: ${user._id}`);
      return res.status(404).json({
        message: "Agent not found"
      });
    }

    const submission = await DocumentSubmission.findById(id);

    if (!submission) {
      logger.warn(`Submission not found: ${id}`);
      return res.status(404).json({
        message: "Submission not found"
      });
    }

    if (submission.agentId.toString() !== agent._id.toString()) {
      logger.warn(`Agent ${agent._id} tried to submit unauthorized submission ${id}`);
      return res.status(403).json({
        message: "You cannot submit this submission"
      });
    }

    if (submission.status !== "DRAFT") {
      logger.warn(`Submission already submitted or not editable: ${submission._id}`);
      return res.status(400).json({
        message: "Submission already submitted"
      });
    }

    logger.info(`Submitting documents for submission ${submission._id}`);

    submission.status = "SUBMITTED";
    submission.submittedAt = new Date();

    await submission.save();

    logger.info(`Submission successful: ${submission._id}`);

    res.status(200).json({
      submissionId: submission._id,
      status: submission.status,
      message: "Documents submitted for review."
    });

  } catch (error) {

    logger.error("Error in submitDocuments API", error);

    next(error);
  }

};

//Admin Reviews the Document
exports.reviewDocuments = async (req, res, next) => {
  try {

    const { id } = req.params;
    const { status, reviewComments } = req.body;
    const adminId = req.user.id;

    logger.info(`Admin ${adminId} reviewing submission ${id}`);

    // Only admin allowed
    if (req.user.role !== "ADMIN") {
      logger.warn(`Unauthorized review attempt by user ${adminId}`);
      return res.status(403).json({
        message: "User is not allowed to perform this operation"
      });
    }

    // Validate review decision
    if (!["APPROVED", "REJECTED"].includes(status)) {
      return res.status(400).json({
        message: "Invalid review status"
      });
    }

    const submission = await DocumentSubmission.findById(id);

    if (!submission) {
      return res.status(404).json({
        message: "Submission not found"
      });
    }

    if (["APPROVED", "REJECTED"].includes(submission.status)) {
      return res.status(400).json({
        message: "Submission already reviewed"
      });
    }

    if (submission.status === "DRAFT") {
      return res.status(400).json({
        message: "Submission not submitted yet"
      });
    }

    if (submission.status !== "SUBMITTED") {
      return res.status(400).json({
        message: "Submission not ready for review"
      });
    }

    // Update submission
    submission.status = status;
    submission.reviewedAt = new Date();
    submission.reviewedBy = adminId;
    submission.reviewComments = reviewComments;

    await submission.save();

    logger.info(`Submission ${id} marked as ${status}`);

    // Create notification
await Notification.create({
  agentId: submission.agentId,
  type: status,
  message:
    status === "APPROVED"
      ? "Your documents have been approved."
      : "Your documents have been rejected.",
  sentAt: new Date(),
  status: "SENT"
});

// Find agent
const agent = await Agent.findById(submission.agentId);

if (!agent) {
  return res.status(404).json({
    message: "Agent not found"
  });
}

// Find user login account
const user = await User.findOne({ email: agent.email });

if (!user) {
  return res.status(404).json({
    message: "User account not found"
  });
}

const message =
  status === "APPROVED"
    ? "Your documents have been approved."
    : "Your documents have been rejected.";

await sendEmail(
  user.email,
  "Document Review Status",
  `Hello Agent,

${message}
Comments: ${reviewComments || "No comments"}`
);

    logger.info(`Review email sent to ${user.email}`);

    res.status(200).json({
      submissionId: submission._id,
      status: submission.status,
      reviewedAt: submission.reviewedAt,
      message: "Review completed."
    });

  } catch (error) {

    logger.error(`Document review error: ${error.message}`);
    next(error);

  }
};