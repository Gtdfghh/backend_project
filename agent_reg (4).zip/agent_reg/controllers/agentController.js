const Agent = require("../models/agent");
const User = require("../models/user");
const Notification = require("../models/notification");
const bcrypt = require("bcrypt");
const logger = require("../utils/logger");
const sendEmail = require("../utils/emailService");
const DocumentSubmission = require("../models/documentSubmission");
const Document = require("../models/document");
const mongoose = require("mongoose");

// REGISTER AGENT

exports.registerAgent = async (req, res, next) => {
  try {

    let {
      email,
      displayName,
      primaryZip,
      coverageRadiusKm,
      hasCamera,
      hasVehicle,
      hasGps,
      hasHighSpeedInternet,
      experienceNotes
    } = req.body;

    email = email.trim().toLowerCase();

    logger.info(`Registration attempt: ${email}`);

    const existing = await Agent.findOne({ email });

    if (existing) {
      return res.status(400).json({
        message: "Email already exists"
      });
    }

    const agent = await Agent.create({
      userId: null,
      email,
      displayName,
      primaryZip,
      coverageRadiusKm,
      hasCamera,
      hasVehicle,
      hasGps,
      hasHighSpeedInternet,
      experienceNotes,
      agentStatus: "PENDING"
    });

    logger.info(`Agent saved: ${agent._id}`);

    await sendEmail(
      email,
      "Application Under Review",
      `Hello ${displayName},

Your form is being reviewed.
We will notify you soon.`
    );

    logger.info(`Email sent to ${email}`);

    res.status(201).json({
      agentId: agent._id,
      agentStatus: "PENDING",
      message: "Registration successful. Awaiting admin approval."
    });

  } catch (error) {

    logger.error(`Agent registration error: ${error.message}`);
    next(error);

  }
};

// ACTIVATE AGENT (ADMIN ONLY)
exports.activateAgent = async (req, res, next) => {
  try {

    logger.info(`Admin ${req.user.id} attempting to activate agent ${req.params.id}`);

    // Check admin role
    if (req.user.role !== "ADMIN") {
      return res.status(403).json({
        message: "User is not allowed to perform this operation"
      });
    }

    // Find agent
    const agent = await Agent.findById(req.params.id);

    if (!agent) {
      return res.status(404).json({
        message: "Agent not found"
      });
    }

    // Check if already activated
    if (agent.agentStatus === "ACTIVE") {
      return res.status(400).json({
        message: "Agent is already activated"
      });
    }

    // Check if user already exists
    const existingUser = await User.findOne({ email: agent.email });

    if (existingUser) {
      return res.status(400).json({
        message: "User account already exists"
      });
    }

    // Generate temporary password
    const tempPassword = Math.random().toString(36).slice(-8);

    // Hash password
    const hashedPassword = await bcrypt.hash(tempPassword, 10);

    // Create user account
    
const user = await User.create({
  email: agent.email,
  password: hashedPassword,
  role: "AGENT",
  status: "ACTIVE"
});

// assign reference
agent.userId = user._id;

// activate agent
agent.agentStatus = "ACTIVE";

// save agent document
await agent.save();   

    // Send email
    await sendEmail(
      agent.email,
      "Agent Account Activated",
      `Hello ${agent.displayName},

Your agent account has been approved.

Login Credentials:
Username: ${agent.email}
Password: ${tempPassword}`
    );

    // Create notification
    await Notification.create({
      agentId: agent._id,
      type: "WELCOME",
      message: "Your agent account has been activated successfully.",
      sentAt: new Date(),
      status: "SENT"
    });

     res.status(200).json({
      agentId: agent._id,
      agentStatus: agent.agentStatus,
      message: "Agent activated successfully"
    });

  } catch (error) {
    logger.error(`Error activating agent: ${error.message}`);
    next(error);
  }
};

//get agents

exports.getAgents = async (req, res, next) => {
  try {

    logger.info("GET /agents API called");

    // Check if admin
    if (req.user.role !== "ADMIN") {
      logger.warn("Unauthorized access attempt to getAgents API");
      return res.status(403).json({
        message: "Only admin can view agents"
      });
    }

    const { status, email, page = 1, limit = 10 } = req.query;

    const filter = {};

    // Filter by status
    if (status) {
      filter.agentStatus = status;
    }

    // Filter by email
    if (email) {
      filter.email = email;
    }

    const skip = (page - 1) * limit;

    logger.info(`Fetching agents with filter: ${JSON.stringify(filter)}`);

    const agents = await Agent.find(filter)
      .skip(skip)
      .limit(Number(limit));

    const totalRecords = await Agent.countDocuments(filter);

    logger.info(`Total agents fetched: ${agents.length}`);

    res.json({
      data: agents,
      pagination: {
        page: Number(page),
        limit: Number(limit),
        totalPages: Math.ceil(totalRecords / Number(limit)),
        totalRecords
      }
    });

  } catch (error) {

    logger.error("Error in getAgents API", error);

    next(error);
  }
};

//get agentDashBoard
exports.getAgentDashboard = async (req, res, next) => {
  try {

    logger.info("GET /agent/dashboard API called");

    if (req.user.role !== "AGENT") {
      logger.warn(`Unauthorized dashboard access attempt by user ${req.user.id}`);
      return res.status(403).json({
        message: "Only agents can upload documents"
      });
    }

    logger.info(`Fetching dashboard for agent userId: ${req.user.id}`);

    const user = await User.findById(req.user.id);

    const agent = await Agent.findOne({ userId: user._id });

    if (!agent) {
      logger.warn(`Agent not found for userId: ${user._id}`);
      return res.status(404).json({
        message: "Agent not found"
      });
    }

    logger.info(`Agent found: ${agent._id}`);

    const submission = await DocumentSubmission.findOne({
      agentId: agent._id
    });

    let submissionStatus = "NONE";
    let documentsUploaded = 0;

    if (submission) {

      submissionStatus = submission.status;

      documentsUploaded = await Document.countDocuments({
        submissionId: submission._id
      });

      logger.info(
        `Submission found for agent ${agent._id}, status: ${submissionStatus}, documents: ${documentsUploaded}`
      );
    } else {
      logger.info(`No submission found for agent ${agent._id}`);
    }

    const notifications = await Notification.find({
      agentId: agent._id
    })
      .sort({ sentAt: -1 })
      .limit(5)
      .select("type message");

    logger.info(`Fetched ${notifications.length} notifications for agent ${agent._id}`);

    res.status(200).json({
      agentStatus: agent.agentStatus,
      currentSubmissionStatus: submissionStatus,
      documentsUploaded,
      notifications
    });

  } catch (error) {

    logger.error("Error in getAgentDashboard API", error);

    next(error);
  }
};
