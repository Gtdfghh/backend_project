const User = require("../models/user");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcrypt");
const logger = require("../utils/logger");

//login


exports.loginUser = async (req, res, next) => {
  try {

    let { email, password } = req.body;

    // Validate input
    if (!email || !password) {
      return res.status(400).json({
        message: "Email and password are required"
      });
    }

    // Normalize email
    email = email.trim().toLowerCase();

    logger.info(`Login attempt for email: ${email}`);

    // Find user
    const user = await User.findOne({ email });

    if (!user) {
      logger.warn(`Login failed - user not found: ${email}`);
      return res.status(401).json({
        message: "Invalid credentials"
      });
    }
    if (user.status !== "ACTIVE") {
  return res.status(403).json({
    message: "Account is inactive"
  });
}
 

    // Compare password with hashed password
    const isMatch = await bcrypt.compare(password, user.password);

    if (!isMatch) {
      logger.warn(`Login failed - incorrect password for: ${email}`);
      return res.status(401).json({
        message: "Invalid credentials"
      });
    }

    // Ensure JWT secret exists
    if (!process.env.JWT_SECRET) {
      throw new Error("JWT_SECRET is not defined in environment variables");
    }

    // Generate token
    const token = jwt.sign(
      { id: user._id, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: "1h" }
    );

    logger.info(`Login successful for user: ${email}`);

    res.status(200).json({
      token,
      user: {
        id: user._id,
        email: user.email,
        role: user.role
      }
    });

  } catch (error) {

    logger.error(`Login error: ${error.message}`);
    next(error);

  }
};