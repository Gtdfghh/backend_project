const express = require("express");
const router = express.Router();

const { registerAgent, activateAgent, getAgents,getAgentDashboard } = require("../controllers/agentController");
const validateAgent = require("../middleware/validateAgent");
const authMiddleware = require("../middleware/authMiddleware");

router.post("/register", validateAgent, registerAgent);
router.get("/dashboard", authMiddleware, getAgentDashboard);
router.get("/", authMiddleware, getAgents);
router.patch("/:id/activate", authMiddleware, activateAgent);

module.exports = router;