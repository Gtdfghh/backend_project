const express = require("express");
const router = express.Router();
const authMiddleware = require("../middleware/authMiddleware");
const validateDocument = require("../middleware/validateDocument");
const upload = require("../middleware/upload");


const {
  createSubmission,
  uploadDocument,
  submitDocuments,
  reviewDocuments
} = require("../controllers/documentController");

router.post("/", authMiddleware, createSubmission);

router.post(
  "/:id/documents",
  authMiddleware,
  upload.array("documents", 3),
  validateDocument,
  uploadDocument
);

router.post("/:id/submit", authMiddleware, submitDocuments);

router.patch("/:id/review", authMiddleware, reviewDocuments);

module.exports = router;




