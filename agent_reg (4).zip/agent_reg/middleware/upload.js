const multer = require("multer");
const { CloudinaryStorage } = require("multer-storage-cloudinary");
const cloudinary = require("../config/cloudinary");

const storage = new CloudinaryStorage({
  cloudinary: cloudinary,
  params: {
    folder: "agent_documents",
    allowed_formats: ["jpg", "png", "pdf"],
    public_id: (req, file) => {
      const name = file.originalname
        .replace(/\.[^/.]+$/, "")
        .replace(/\s+/g, "_");
      return Date.now() + "-" + name;
    }
  }
});

//  ADD THIS BACK
const fileFilter = (req, file, cb) => {
  const allowedTypes = [
    "application/pdf",
    "image/jpeg",
    "image/png"
  ];

  if (allowedTypes.includes(file.mimetype)) {
    cb(null, true);
  } else {
    cb(new Error("Invalid file type. Only PDF, JPEG, PNG allowed"), false);
  }
};

const upload = multer({
  storage: storage,
  fileFilter: fileFilter, 
  limits: { fileSize: 5 * 1024 * 1024 }
});

module.exports = upload;
