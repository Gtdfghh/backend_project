const logger = require("../utils/logger");

const errorHandler = (err, req, res, next) => {

  logger.error(err.message);

  //  Handle Invalid JSON Format
  if (err instanceof SyntaxError && err.status === 400 && "body" in err) {
    return res.status(400).json({
      message: "Invalid JSON format"
    });
  }

  //  Handle Mongoose Validation Error
  if (err.name === "ValidationError") {
    return res.status(400).json({
      message: err.message
    });
  }

  //  Handle Duplicate Key Error
  if (err.code === 11000) {
    return res.status(400).json({
      message: "Duplicate field value"
    });
  }
  if (err.message && err.message.includes("Invalid file type")) {
  return res.status(400).json({
    message: err.message
  });
}
  //  Default Error
  res.status(500).json({
    message: "Internal Server Error"
  });
};

module.exports = errorHandler;