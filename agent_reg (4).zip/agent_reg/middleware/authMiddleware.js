const jwt = require("jsonwebtoken");
const logger = require("../utils/logger");

module.exports = (req, res, next) => {

  const authHeader = req.headers.authorization;

  if (!authHeader) {
    logger.warn("Authorization header missing");

    return res.status(401).json({
      message: "Token required"
    });
  }

  const parts = authHeader.split(" ");

  if (parts.length !== 2 || parts[0] !== "Bearer") {
    logger.warn("Invalid authorization header format");

    return res.status(401).json({
      message: "Invalid token format"
    });
  }

  const token = parts[1];

  try {

    if (!process.env.JWT_SECRET) {
      throw new Error("JWT_SECRET not configured");
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    req.user = decoded;

    next();

  } catch (error) {

    logger.warn(`JWT verification failed: ${error.message}`);

    return res.status(401).json({
      message: "Invalid or expired token"
    });

  }

};