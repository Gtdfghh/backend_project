const { body, validationResult } = require("express-validator");

const validateAgent = [

  body("email")
    .notEmpty().withMessage("Email is required")
    .isEmail().withMessage("Invalid email format"),

  body("displayName")
    .notEmpty().withMessage("Display name is required"),
    body("primaryZip")
    .notEmpty().withMessage("Primary ZIP is required")
    .matches(/^[0-9]{6}$/)
    .withMessage("Primary ZIP must be a valid 6 digit code"),

  body("coverageRadiusKm")
    .notEmpty().withMessage("Coverage radius is required")
    .isNumeric().withMessage("Coverage radius must be a number")
    .custom(value => {
      if (value <= 0) {
        throw new Error("Coverage radius must be greater than 0");
      }
      return true;
    }),

  (req, res, next) => {

    const errors = validationResult(req);

    if (!errors.isEmpty()) {
      return res.status(400).json({
        message: errors.array()[0].msg
      });
    }

    next();
  }

];

module.exports = validateAgent;

