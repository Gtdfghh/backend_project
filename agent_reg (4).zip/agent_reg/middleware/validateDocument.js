const logger = require("../utils/logger");

module.exports = (req, res, next) => {

  //  Check files exist
  if (!req.files || req.files.length === 0) {
    return res.status(400).json({
      message: "At least one file is required"
    });
  }

  const validatedFiles = [];

  // Loop through all files
  for (const file of req.files) {

    const fileName = file.filename;
    const originalFileName = file.originalname;
    const contentType = file.mimetype;
    const fileSizeBytes = file.size;
    const fileUrl = file.path;

    //  Validate size type
    if (typeof fileSizeBytes !== "number") {
      logger.warn("Document validation failed: invalid file size");

      return res.status(400).json({
        message: "Invalid file size"
      });
    }

    //  Validate size limit
    if (fileSizeBytes > 5 * 1024 * 1024) {
      logger.warn(`Uploaded file exceeds size limit: ${fileSizeBytes}`);

      return res.status(400).json({
        message: "File size exceeds 5MB limit"
      });
    }

    validatedFiles.push({
      fileName,
      originalFileName,
      fileUrl,
      contentType,
      fileSizeBytes
    });
  }

  //  Store all validated files
  req.documentData = validatedFiles;

  next();
};