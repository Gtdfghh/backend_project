const mongoose = require("mongoose");

const documentSubmissionSchema = new mongoose.Schema({

  agentId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Agent",
    required: true,
    index: true
  },

  status: {
    type: String,
    enum: ["DRAFT", "SUBMITTED", "APPROVED", "REJECTED"],
    default: "DRAFT"
  },

  submittedAt: Date,

  reviewedAt: Date,

  reviewedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User"
  },

  reviewComments: {
    type: String,
    maxlength: 500
  }

}, { timestamps: true });

module.exports = mongoose.model("DocumentSubmission", documentSubmissionSchema);