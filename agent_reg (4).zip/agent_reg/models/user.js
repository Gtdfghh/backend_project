const mongoose = require("mongoose");

const userSchema = new mongoose.Schema({

  email: {
    type: String,
    required: true,
    unique: true,
    lowercase: true,
    trim: true,
    match: [/^\S+@\S+\.\S+$/, "Invalid email format"]
  },

  password: {
    type: String,
    required: true
  },

  role: {
    type: String,
    enum: ["ADMIN", "AGENT"],
    default: "AGENT"
  },
  status: {
  type: String,
  enum: ["ACTIVE", "INACTIVE"],
  default: "ACTIVE"
}
   

}, { timestamps: true });

module.exports = mongoose.model("User", userSchema);