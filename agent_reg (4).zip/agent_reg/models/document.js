const mongoose = require("mongoose");

const documentSchema = new mongoose.Schema({

  submissionId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "DocumentSubmission",
    required: true
  },

  fileName: {
    type: String,
    required: true
  },

  originalFileName: {
    type: String,
    required: true
  },

  fileUrl: {
    type: String,
    required: true
  },

  contentType: {
    type: String,
    required: true
  },

  fileSizeBytes: {
    type: Number,
    required: true
  },

  uploadedAt: {
    type: Date,
    default: Date.now
  }

});

module.exports = mongoose.model("Document", documentSchema);