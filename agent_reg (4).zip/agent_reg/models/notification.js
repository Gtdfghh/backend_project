const mongoose = require("mongoose");

const notificationSchema = new mongoose.Schema({

  agentId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Agent",
    required: true,
    index: true
  },

  type: {
    type: String,
    enum: ["WELCOME", "APPROVED", "REJECTED"],
    required: true
  },

  message: {
    type: String,
    required: true,
    maxlength: 500
  },

  sentAt: {
    type: Date,
    default: Date.now
  },

  status: {
    type: String,
    enum: ["SENT", "FAILED"],
    default: "SENT"
  }

}, { timestamps: true });

module.exports = mongoose.model("Notification", notificationSchema);