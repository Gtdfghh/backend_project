const mongoose = require("mongoose");

const agentSchema = new mongoose.Schema({

   
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
     default: null
  },

  email: {
    type: String,
    required: [true, "Email is required"],
    unique: true,
    lowercase: true,
    trim: true,
    match: [/^\S+@\S+\.\S+$/, "Invalid email format"]
  },

  displayName: {
    type: String,
    required: [true, "Display name is required"],
    validate: {
      validator: v => /^[A-Za-z\s]+$/.test(v),
      message: "Display name must contain only letters"
    }
  },

  primaryZip: {
    type: String,
    required: true
  },

  coverageRadiusKm: {
    type: Number,
    required: true
  },

  hasCamera: Boolean,
  hasVehicle: Boolean,
  hasGps: Boolean,
  hasHighSpeedInternet: Boolean,

  experienceNotes: String,

  agentStatus: {
    type: String,
    enum: ["PENDING", "ACTIVE", "REJECTED", "SUSPENDED"],
    default: "PENDING"
  }

}, { timestamps: true });

module.exports = mongoose.model("Agent", agentSchema);