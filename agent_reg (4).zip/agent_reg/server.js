require("dotenv").config();
const express = require("express");
const connectDB = require("./config/db");
const errorHandler = require("./middleware/errorHandler");
const agentRoutes = require("./routes/agentRoutes");
const authRoutes = require("./routes/authRoutes");
const logger = require("./utils/logger");
const documentRoutes = require("./routes/documentRoutes");

const app = express();

connectDB();

app.use(express.json());

// routes
app.use("/api/agents", agentRoutes);
app.use("/api/auth", authRoutes);
app.use("/api/submissions", documentRoutes);

// 404
app.use((req, res) => {
  res.status(404).json({ message: "Route not found" });
});

app.use(errorHandler);

const PORT = process.env.PORT || 3000;

if (process.env.NODE_ENV !== "test") {
  app.listen(PORT, () => {
    logger.info(`Server running on port ${PORT}`);
  });
}

module.exports = app;


